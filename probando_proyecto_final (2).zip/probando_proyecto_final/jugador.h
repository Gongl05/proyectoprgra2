#ifndef JUGADOR_H
#define JUGADOR_H

#include <iostream>
#include "tablero.h" // Asegúrate de incluir el archivo de encabezado del tablero

class jugador {
    string username;
    string pieza;
    string casilla;
    int puntaje = 0;

public:
    jugador(string username, string pieza, string casilla);
    string** modificar_matriz(tablero* tablero, int x0, int y0, int x, int y, string w);
    bool validar_movimiento(tablero* tablero, int x0, int y0, int x, int y, jugador* a, jugador* b);

    string get_username();
    string get_pieza();
    string get_casilla();
    int get_puntaje();
    void sumar_puntaje();
};

#endif //JUGADOR_H
