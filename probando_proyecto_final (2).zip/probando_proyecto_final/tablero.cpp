#include "tablero.h"

// Constructor
tablero::tablero(int sz) {
    this->sz = sz;
    matriz = new string*[sz];
    for(int i = 0; i < sz; i++) {
        matriz[i] = new string[sz];
    }
}

// Destructor
tablero::~tablero() {
    for(int i = 0; i < sz; i++) {
        delete[] matriz[i];
    }
    delete[] matriz;
}

// Funcion para rellenar la matriz
string** tablero::relleno_matriz(string** matriz, int sz) {
    int x = 0;
    for(int i = 0; i < sz; i++) {
        for(int j = 0; j < sz; j++) {
            matriz[i][j] = "0";
            if(i == 0 || i % 2 == 0) {
                matriz[i][j] = " + ";
                if(j % 2 != 0) {
                    matriz[i][j] = " ";
                    x++;}}
            else {if(j == 0 || j % 2 == 0) {
                    matriz[i][j] = "   ";
                    x++;}}}}
    return matriz;}

// Funcion para imprimir la matriz en pantalla con las coordenadas
void tablero::imprimir_matriz(string** matriz, int sz) {
    int x = 0;
    cout << " ";
    for(int i = 0; i < sz; i = i + 2) {
        cout << "  " << x + 1 << " ";
        x++;}
    x = 0;
    cout << endl;
    for(int i = 0; i < sz; i++) {
        for(int j = 0; j < sz; j++) {
            if(j == 0) {
                if (i == 0 || i % 2 == 0) {
                    cout << x + 1;
                    x++;}
                else {cout << " ";}cout << " ";}
            if(matriz[i][j] == "0") {cout << " ";}
            else {cout << matriz[i][j];}}cout <<endl;}}
