#ifndef TABLERO_H
#define TABLERO_H

#include <iostream>
#include <string>
using namespace std;

class tablero {
public:
    string **matriz;
    int sz;
    tablero(int sz);
    ~tablero();
    string** relleno_matriz(string** matriz, int sz);
    void imprimir_matriz(string** matriz, int sz);
    string obtenerMatrizComoString(string** matriz, int sz) {
        string resultado;
        int x = 0;
        resultado += " ";
        for (int i = 0; i < sz; i = i + 2)
        {resultado += "  " + to_string(x + 1) + " ";x++;}
        x = 0;
        resultado += "\n";
        for (int i = 0; i < sz; i++) {
            for (int j = 0; j < sz; j++) {
                if (j == 0) {
                    if (i == 0 or i % 2 == 0) {
                        resultado += to_string(x + 1);
                        x++;
                    } else {
                        resultado += " ";}
                    resultado += " ";}
                if (matriz[i][j] == "0") {
                    resultado += " ";
                } else {
                    resultado += matriz[i][j];}
            }resultado += "\n";}
        return resultado;}};

#endif //TABLERO_H
