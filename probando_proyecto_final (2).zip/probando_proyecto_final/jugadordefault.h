#include "jugador.h"


class jugadordefault : public jugador {

public:
    jugadordefault() : jugador("jugador A", "*", "A") {}
};



