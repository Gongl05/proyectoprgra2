#include "jugador.h"
using namespace std;
jugador::jugador(string username, string pieza, string casilla) {
    this->username = username;
    this->pieza = pieza;
    this->casilla = casilla;}

string** jugador::modificar_matriz(tablero* tablero, int x0, int y0, int x, int y, string w){
    int sz = tablero->sz;
    string **matriz = tablero->matriz;
    x0 = x0 * 2 - 2;
    y0 = y0 * 2 - 2;
    x = x * 2 - 2;
    y = y * 2 - 2;
    for (int i = 0; i < sz; i++) {
        for (int j = 0; j < sz; j++) {
            if(x0 == x){
                if(y>y0){matriz[x0][y-1] =w;}
                else {matriz[x0][y0-1]= w ;}}
            else if(y0==y){
                if(x0>x){matriz[x0-1][y]= " "+ w + " ";}
                else{matriz[x-1][y]= " "+ w + " ";}}}}
    return matriz;}

bool jugador::validar_movimiento(tablero* tablero, int x0, int y0, int x, int y, jugador* a, jugador* b) {
    int sz = tablero->sz;
    string** matriz = tablero->matriz;
    int xt0 = x0, yt0 = y0, xt = x, yt = y;
    x0 = x0 * 2 - 2;
    y0 = y0 * 2 - 2;
    x = x * 2 - 2;
    y = y * 2 - 2;

    if ((x0 == x && y0 == y)) {
        cout << endl << "-------------------------------" << endl;
        cout << "No estas avanzando ninguna casilla " << endl;
        cout << "Intenta poner un final diferente al inicio, " << a->get_username() << endl;
        cout << "-------------------------------" << endl;
        return false;
    }
    if ((x0 == y && y0 == x)) {
        cout << endl << "-------------------------------" << endl;
        cout << "¿Intentas trabar el juego?" << endl;
        cout << "Pon casillas que sigan las reglas, " << a->get_username() << endl;
        cout << "-------------------------------" << endl;
        return false;
    }

    if ((x0 == y0 && x == y)) {
        cout << endl << "-------------------------------" << endl;
        cout << "No se pueden hacer movimientos diagonales." << endl;
        cout << "Intenta ir en linea recta esta vez, " << a->get_username() << endl;
        cout << "-------------------------------" << endl;
        return false;
    }

    // Verificar si el movimiento es largo
    if (x0 == x) {
        if (abs(yt0 - yt) != 1) {
            cout << endl << "-------------------------------" << endl;
            cout << "Estas avanzando bien en x, recuerda que en las y es +1 o -1." << endl;
            cout << "Intentalo de nuevo, " << a->get_username() << endl;
            cout << "-------------------------------" << endl;
            return false;
        }
    }
    if (y0 == y) {
        if (abs(xt0 - xt) != 1) {
            cout << endl << "-------------------------------" << endl;
            cout << "Estas avanzando bien en y, recuerda que en las x es +1 o -1." << endl;
            cout << "Intentalo de nuevo, " << a->get_username() << endl;
            cout << "-------------------------------" << endl;
            return false;
        }
    }
    if (!(x0 == x || y0 == y)) {
        cout << endl << "-------------------------------" << endl;
        cout << "Movimiento invalido, " << a->get_username() << endl;
        cout << "Intentalo de nuevo, bro" << endl;
        cout << "-------------------------------" << endl;
        return false;
    }

    // Por si las piezas están ocupadas
    for (int i = 0; i < sz; i++) {
        for (int j = 0; j < sz; j++) {
            if (x0 == x) {
                if (y > y0) {
                    if (matriz[x0][y - 1] == b->get_pieza() || matriz[x0][y - 1] == a->get_pieza()) {
                        cout << endl << "-------------------------------" << endl;
                        cout << "Espacio ocupado por el " << b->get_username() << endl;
                        cout << "Intenta de nuevo, " << a->get_username() << endl;
                        cout << "-------------------------------" << endl;
                        return false;}}
                else {
                    if (matriz[x0][y0 - 1] == b->get_pieza() || matriz[x0][y0 - 1] == a->get_pieza()) {
                        cout << endl << "-------------------------------" << endl;
                        cout << "Ya esta lleno " << endl;
                        cout << "Escoge uno vacio, " << a->get_username() << endl;
                        cout << "-------------------------------" << endl;
                        return false;}}}
            else if (y0 == y) {
                if (x > x0) {
                    if (matriz[x - 1][y0] == " " + b->get_pieza() + " " || matriz[x - 1][y0] == " " + a->get_pieza() + " ") {
                        cout << endl << "-------------------------------" << endl;
                        cout << "Muy lento, te ganaron el espacio" << endl;
                        cout << "Intenta otro " << a->get_username() << endl;
                        cout << "-------------------------------" << endl;
                        return false;}}
                else {
                    if (matriz[x0 - 1][y0] == " " + b->get_pieza() + " " || matriz[x0 - 1][y0] == " " + a->get_pieza() + " ") {
                        cout << endl << "-------------------------------" << endl;
                        cout << "Espacio ocupado." << endl;
                        cout << "Intenta de nuevo " << a->get_username() << endl;
                        cout << "-------------------------------" << endl;
                        return false;
                    }}}}}
    return true;}

string jugador::get_username() {return username;}
string jugador::get_pieza() {return pieza;}
string jugador::get_casilla() {return casilla;}
int jugador::get_puntaje() {return puntaje;}
void jugador::sumar_puntaje() {puntaje++;}