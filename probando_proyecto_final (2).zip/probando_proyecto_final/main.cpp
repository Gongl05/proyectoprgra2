// INTEGRANTES:
// Gaviño, Gonzalo (202210146)
// Natal, Marcelo (202210221)
// Salazar, Julio (202210311)

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "jugador.h"
#include "jugadordefault.h"

void logo(){
    cout << "       DOTS           _______" << endl;
    cout << "     _______         /\\O    O\\" << endl;
    cout << "    / O    /\\       /  \\      \\" << endl;
    cout << "   /   O  /O \\     / O  \\O____O\\   " << endl;
    cout << "  /_____O/    \\  & \\    /O     /" << endl;
    cout << "  \\O    O\\    /     \\  /   O  /" << endl;
    cout << "   \\O    O\\ O/       \\/_____O/" << endl;
    cout << "    \\O____O\\/          BOXES    " << endl;
}

void bienvenida(){
    cout << "            WELCOME TO"<<endl<< endl;
    logo();
    cout<<endl<<endl<<"Presione enter para continuar ...."<<endl;
    cin.get();
}

int inicializar_tablero(){
    // Selecionamos el tamaño del tablero
    cout << "Seleccione el tamano del tablero: " << endl;
    cout << "1. 6x6" << endl; // int sz = 7
    cout << "2. 10X10" << endl; // int sz = 9
    cout << "0. salir" << endl;
    cout << "En caso de seleccionar otro numero el tablero sera de 3x3" << endl;

    int sz, opcion;

    cin >> opcion;
    switch (opcion) {
        case 0: sz = 0;break;
        case 1:sz = 11;break;
        case 2:sz = 19; break;
        default: sz = 5 ; break;
    }
    return sz;
};

bool verificador_exitencia_puntos(int max,int x0,int y0,int x,int y){
    if(x0>0 && x0<=max && y0>0 && y0<=max && x>0 && x<=max && y>0 && y<=max){
        return true;
    }
    return false;
}

// Funcion movimiento de jugador
void movimiento_jugador(jugador *jugador1,jugador *jugador2, tablero *tablero, int sz){
    int x0,y0,x,y;
    cout << "Ingrese las coordenadas del punto de inicio: " << endl;
    cin >> x0 >> y0;
    cout << "Ingrese las coordenadas del punto de fin: " << endl;
    cin >> x >> y;
    string **matriz;
    string w = jugador1->get_pieza();
    // Verificamos que las coordenadas ingresadas no esten fuera del tablero
    if ((verificador_exitencia_puntos(sz - (sz-1)/2 ,x0,y0,x,y))){
        if ((jugador1->validar_movimiento(tablero,x0,y0,x,y,jugador1,jugador2))){
            matriz = jugador1->modificar_matriz(tablero,x0,y0,x,y, w);
            tablero->matriz = matriz;}
        else{tablero->imprimir_matriz(tablero->matriz,tablero->sz);
            movimiento_jugador(jugador1,jugador2,tablero,sz);}
    }
    else{
        cout << "El punto no esta dentro del tablero :c "<<endl;
        cout << "intenta de nuevo " << jugador1->get_username() << endl;
        tablero->imprimir_matriz(tablero->matriz,tablero->sz);
        movimiento_jugador(jugador1,jugador2,tablero,sz);
    }
};

// Funcion para verificar si el algun jugador gano un cuadrado en caso de que si se suma 1 al puntaje del jugador
bool verificar_cuadrado(jugador *jugador1, jugador *jugador2, tablero *tablero, int sz) {
    string **matriz = tablero->matriz;
    string w = jugador1->get_pieza();
    string w2 = jugador2->get_pieza();

    // Iterar sobre los puntos que pueden ser esquina superior izquierda de un cuadrado
    for (int i = 1; i < sz; i += 2) {
        for (int j = 1; j < sz; j += 2) {
            // Verificar si el cuadrado está vacío
            if (matriz[i][j] == "0") {
                // Verificar si las cuatro esquinas del cuadrado están ocupadas por el mismo jugador
                if (matriz[i][j-1] != "   "
                    && matriz[i][j+1] != "   "
                    && matriz[i-1][j] != " "
                    && matriz[i+1][j] != " " ){
                    jugador1->sumar_puntaje();
                    cout << jugador1->get_username() << " GANASTE UN PUNTOOOO " << endl;
                    matriz[i][j] = jugador1->get_casilla();
                    cout << "Te toca de nuevo te lo mereces ";
                    return true;
                }


            }
        }
    }
    return false;
}

void puntajes(vector<jugador> jugadores){
    cout << jugadores[0].get_username() << ": " << jugadores[0].get_puntaje() << " - " << jugadores[1].get_username() << ": " << jugadores[1].get_puntaje() << endl;
}

void guardarHistorial(vector<string> historial, vector<jugador> jugadores, tablero tablero) {
    ofstream archivo("historial.txt", ios::app); // 'app' para agregar al final del archivo

    if (archivo.is_open()) {
        for (const string& linea : historial) {
            archivo << linea << endl;}

        archivo << "----------------------------\n";
        archivo << "Resultados de la partida:\n\n";
        archivo <<"Tablero:\n";
        archivo << tablero.obtenerMatrizComoString(tablero.matriz,tablero.sz) << "\n\n";

        archivo <<"Puntaje:\n";

        for (jugador& j : jugadores) {
            archivo << j.get_username() << ": " << j.get_puntaje() << " puntos\n";
        }
        archivo<<"\n";

        if (jugadores[0].get_puntaje() > jugadores[1].get_puntaje()) {
            archivo << "Ganador: " << jugadores[0].get_username() << "\n";
        } else if (jugadores[0].get_puntaje() < jugadores[1].get_puntaje()) {
            archivo << "Ganador: " << jugadores[1].get_username() << "\n";
        } else {
            archivo << "Empate\n";
        }

        archivo << "----------------------------\n";
        archivo.close();
    } else {cout << "No se pudo abrir el archivo para guardar el historial." << endl;}}

int main(){
    bienvenida();

    int sz = inicializar_tablero();
    if(sz==0){return 0;}
    // Creamos un objeto tablero
    tablero tablero(sz);

    // Rellenamos la matriz del tablero
    tablero.matriz = tablero.relleno_matriz(tablero.matriz,tablero.sz);

    // Creamos un vector de jugadores
    vector<jugador> jugadores;
    vector<string> historial;
    // Inicializamos los jugadores
    jugadores.push_back(jugadordefault());
    jugadores.push_back(jugador("Jugador B","~","B"));

    // Movimiento de los jugadores
    int turno = 0;
    bool gano;
    do{
        cout << endl << "-------------------------------"<<endl;
        cout << "Turno de " << jugadores[turno].get_username() << endl;
        // Mostramos el puntaje de los jugadores
        puntajes(jugadores);

        cout <<"-------------------------------"<<endl;

        tablero.imprimir_matriz(tablero.matriz,tablero.sz);

        movimiento_jugador(&jugadores[turno],&jugadores[turno==0?1:0],&tablero,sz);
        gano = verificar_cuadrado(&jugadores[turno],&jugadores[turno==0?1:0],&tablero, sz);

        if (!gano){
            turno = (turno + 1) % 2;
        }
    } while (jugadores[0].get_puntaje() + jugadores[1].get_puntaje() != ((sz - 1) / 2) * ((sz - 1) / 2));


    // Mostramos el puntaje de los jugadores
    cout << endl << "-------------------------------" << endl;
    cout << jugadores[0].get_username() << ": " << jugadores[0].get_puntaje() << " - " << jugadores[1].get_username() << ": " << jugadores[1].get_puntaje() << endl;
    cout << "-------------------------------" << endl;
    tablero.imprimir_matriz(tablero.matriz,tablero.sz);
    cout << endl;

    guardarHistorial(historial, jugadores, tablero);


    cout << "Resultados de la partida: "<<endl;
    // Mostramos el ganador
    if (jugadores[0].get_puntaje() > jugadores[1].get_puntaje()){
        cout << " - El ganador es: " << jugadores[0].get_username() << endl;

    } else if (jugadores[0].get_puntaje() < jugadores[1].get_puntaje()){
        cout << " - El ganador es: " << jugadores[1].get_username() << endl;
    } else {
        cout << " - Empate" << endl;
    }

    // Fin del programa
    return 0;
}